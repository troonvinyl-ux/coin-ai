# KeenOnCoins — Three App Hub

This package contains the three apps requested:

- `client/` + `server/` — Coin AI / KeenOnCoins listing workspace
- `apps/metronome/` — installable mobile web metronome
- `apps/iphone-share-phone/` — iPhone controller
- `apps/iphone-share-tv/` — Android TV / Fire TV receiver APK project
- `.github/workflows/build-iphone-share-tv.yml` — GitHub Actions APK build

## Important
No Azure OpenAI or eBay secrets are included in the project.

The Coin AI UI is prepared for:
1. Coin photo capture/upload
2. AI identification
3. Human review/edit
4. eBay listing draft creation

When the eBay developer credentials are available, the server can be connected to the eBay APIs without exposing secrets in the browser.

## Run Coin AI locally

```bash
cd server
npm install
cp .env.example .env
npm start
```

Then open `http://localhost:3000`.

## Metronome
Open `apps/metronome/index.html` from a static web host. It is designed for mobile use and can be installed as a PWA when served over HTTPS.

## iPhone Share
Build the Android TV project with Android Studio or GitHub Actions. Install the resulting APK on the Fire Stick/Android TV, note the TV address, then open that address from Safari on the iPhone.
