# Live integrations
Numista: set NUMISTA_API_KEY. Image identification accepts obverse/reverse images.
AI: add a server-side model adapter for visual reasoning and listing copy; keep keys off the client.
eBay: implement OAuth and Inventory API. eBay requires an inventory location, inventory item, offer and seller business policies before publishing. Keep PUBLISH disabled until these are configured.
