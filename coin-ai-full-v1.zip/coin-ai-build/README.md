# Coin AI
Mobile-first coin identification workflow: PHOTO → EVIDENCE → IDENTIFY → VERIFY → VALUE → EBAY DRAFT.

V1 includes a working React/Vite interface plus a Node API layer. It runs in demo mode without credentials. Add server-side API keys to enable live providers.

Run: `npm install` then `npm run dev`.

Never put API keys in the client.
