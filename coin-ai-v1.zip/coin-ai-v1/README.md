# Coin AI
Mobile-first coin identification and eBay listing assistant.

V1 prototype: evidence capture, transparent identification workflow and eBay listing preview. Live Numista/AI/eBay credentials should be added server-side and never committed to the repository.

## Run
npm install
npm run dev
